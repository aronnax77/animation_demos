game.resources = [
    { name : "texture", type : "json", src : "data/img/cityscene.json" },
    { name : "texture", type : "image", src : "data/img/cityscene.png" }
];
